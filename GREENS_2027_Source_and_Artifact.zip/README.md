# Auditing Energy Claims for Exact Frame Reuse on a Laptop GPU

This package accompanies the GREENS 2027 Emerging Research manuscript by Ishan Teredesai and Tushar Rahangadle. The author-designated project address is https://github.com/titcsl/reuse-model. The completed follow-up is the primary experiment. The interrupted pilot is preserved separately.

The manuscript uses the required IEEE conference layout and includes the author-supplied contacts: Ishan Teredesai, `001@ddm.in`; Tushar Rahangadle, `002@ddm.in`. Read `SUBMISSION_GUIDE.md` before uploading the paper. Reviewers can begin with `REVIEWER_START_HERE.md`; the assessment of the additional advice is in `REVISION_DECISIONS.md`.

## Contents

| Item | Purpose |
|---|---|
| `GREENS_2027_Emerging_Research.pdf` | Compiled manuscript |
| `GREENS_2027_Emerging_Research.tex` | Main LaTeX source; tables and figure are included from subfolders |
| `data/` | Both unmodified acquisition CSVs |
| `analyze.py` | Recomputes trial statistics and audits the raw acquisition |
| `render_results.py` | Regenerates the manuscript tables and scientific figures |
| `verify_artifact.py` | Checks source provenance, workload traces, plan, comments and headline counts |
| `build.py` | Runs the complete analysis and PDF build |
| `benchmark/gpu_audit_v3.py` | Readable, comment-free derivative of the executed follow-up program |
| `benchmark/kernels.cu` | Comment-free representation of the same CUDA kernel logic |
| `restore_executed.py` | Restores the exact executed source embedded in a CSV |
| `results/` | Trial tables, individual contrasts, diagnostics and audit reports |
| `figures/` | Vector PDF and raster PNG figures |
| `provenance/` | Source identities and the documented formatting changes |
| `REVIEW_RESPONSE.md` | Point-by-point response to the previous audit |
| `REVISION_DECISIONS.md` | Assessment and disposition of the additional advice |
| `REVIEWER_START_HERE.md` | Short path from manuscript claims to the archived evidence |
| `REFERENCE_AUDIT.md` | Reference verification and unresolved metadata |
| `SUBMISSION_GUIDE.md` | Upload instructions and remaining author actions |
| `SHA256SUMS.txt` | File integrity manifest |

## Reproduce the analysis

Extract the full source-and-artifact ZIP. Open a terminal in its extracted folder. Use Python 3.12 for the pinned analysis dependencies; the acquisition used the Python version recorded in the CSV. If Windows defaults to Python 3.14, create the environment with `py -3.12 -m venv .venv` after installing Python 3.12. The benchmark itself uses only the standard library.

```sh
python -m venv .venv
```

On Windows Command Prompt:

```bat
.venv\Scripts\activate
python -m pip install -r requirements.txt
python build.py --analysis-only
```

On Linux or macOS:

```sh
source .venv/bin/activate
python -m pip install -r requirements.txt
python build.py --analysis-only
```

The command reads the existing measurements; it does not start a GPU benchmark. Expected follow-up checks are 144 completed trials, 204,297 iterations, 1,788 correctness comparisons, 144 final-image checks, and 10 sign disagreements among 36 main-policy contrasts. The pilot remains 88 completed trials and 23 disagreements among 48 contrasts. No failed or incomplete pilot rows are deleted from the raw CSV.

To rebuild the PDF after installing a TeX distribution with `pdflatex`:

```sh
python build.py
```

The ZIP includes the unchanged IEEEtran class and its README. Standard LaTeX packages `cite`, `amsmath`, `amssymb`, `graphicx`, `booktabs`, `url` and `hyperref` are also required. The smaller LaTeX ZIP can be imported directly into Overleaf; choose `GREENS_2027_Emerging_Research.tex` as the main document and compile with pdfLaTeX. No Python or raw data are needed for that route because the generated tables and figure are included.

## Run the benchmark only for a new experiment

The supplied 144-trial CSV is complete. Another run is not required merely to regenerate this paper. A new run would be a separate acquisition, not a replacement selected to obtain more favorable measurements.

For an exact-source replication, restore the program first:

```sh
python restore_executed.py data/gpu_audit_v3_20261106_153155_70b1e6.csv executed/gpu_audit_v3.py
python executed/gpu_audit_v3.py --self-test
python executed/gpu_audit_v3.py --plan
```

The first command refuses to overwrite an existing file. Restoration does not execute the embedded source. The restored file contains the comments present in the original acquisition; those bytes are evidence and are not rewritten.

On the Windows NVIDIA laptop, with 64-bit Python and the NVIDIA driver available:

```sh
python executed/gpu_audit_v3.py --smoke --output-dir new_runs
python executed/gpu_audit_v3.py --output-dir new_runs
```

The smoke test is setup validation, not study data. The full run has 144 trials in four processes. The observed follow-up lasted 69.18 minutes; allow the protocol's estimated 75–95 minutes or longer on another configuration. Keep AC power connected. The program records failure and interruption status and restores its temporary console/sleep settings on exit. Retain any incomplete CSV. The fixed-data analysis checks the two supplied CSV hashes, so it will reject a replacement acquisition until a separate analysis dataset is explicitly configured.

The readable benchmark can be inspected or host-tested with `python benchmark/gpu_audit_v3.py --self-test`. Its executable Python structure, CUDA tokens and embedded compiled PTX were checked against the exact source. It has a different source checksum because comments, documentation and formatting changed. It was not the file that produced the reported CSV. See `provenance/readable_source.json`.

## Scope of the evidence

These are observations from one laptop and driver configuration. Four process sessions in one sitting are not independent days or devices. All primary energy results are software telemetry estimates. No external energy meter, physical calibration, equivalence test or causal driver diagnosis is supplied.

The authored Python and readable CUDA files contain no comments or docstrings. Documentation is kept in Markdown. Original source embedded in the unmodified CSV, generated compiled PTX, and the third-party IEEEtran distribution retain their original bytes and notices.
