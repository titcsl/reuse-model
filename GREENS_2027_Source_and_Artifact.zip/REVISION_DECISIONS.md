# Assessment of the additional advice and applied revisions

Checked on 6 November 2026 against the current manuscript, artifact and unchanged raw acquisitions.

## Overall judgment

Apply the remaining presentation and submission fixes. Do not copy the proposed contribution paragraph verbatim or run another experiment merely to satisfy advice based on the old pilot. The current paper already reports the completed follow-up requested by that advice.

The renderer is an implemented, controlled CUDA workload with explicit dependencies. Its mathematical rule explains invalidation; hardware execution, image comparisons, timing and telemetry supply the empirical evidence. Designing the workload is legitimate. The research contribution rests on what the experiments establish and how the audit can help evaluate other optimizations. The synthetic workload still limits generalization.

GREENS Emerging Research is a plausible venue for this bounded case study. The public call still asks for novel results and assesses technical quality, relevance, significance and clarity. Workshop status does not remove those criteria, and no reliable acceptance probability can be inferred from the available evidence.

## Decisions on the supplied advice

| Suggestion | Verification | Decision and change |
|---|---|---|
| A. Make the artifact accessible and separate analysis from acquisition. | The existing archive already contains both raw CSVs, source recovery, audit scripts and separate run instructions. The reviewer explicitly said it had not inspected these. A downloadable package is not automatically accessible to conference reviewers. | Retain the complete archive, add `REVIEWER_START_HERE.md`, identify the package and analysis command in the paper, and make the upload step explicit in `SUBMISSION_GUIDE.md`. Actual reviewer access depends on attaching it or providing a real permitted archive link. |
| B. Sharpen the contribution. | Useful, but the proposed replacement uses the pilot's 16 blocks and 23/48 count. The completed follow-up has 12 main blocks and 10/36 disagreements. | Rewrite the contribution around the completed 144-trial study, the three reuse policies, and the polling, no-launch, copy and sustained controls. Explain why explicit dependencies were chosen. |
| C. Add fresh monitoring repetitions. | Already implemented in the separate follow-up: four fresh process sessions, 52 polling-sweep trials, 24 idle/copy controls, eight A/A trials, eight explicit-field trials and four sustained trials, alongside 48 main comparisons. The raw log confirms 144 completed trials and 36 planned trials per process. | No new run is required to address this request. Keep the pilot and follow-up separate. Retain all current observations and the limitations of within-sitting replication. |
| D. Consolidate repeated caveats. | The current paper repeats some calibration, scope and method qualifications. Some local cautions are necessary to interpret the reported quantities. | Shorten the introduction, related-work qualifications and repeated result caveats. Keep the full measurement and generalization limits in Threats to Validity, plus local warnings about descriptive slopes, shared baselines and confounded sustained-load comparisons. |
| E. Add author contacts and check format. | Emails were missing. The user has now supplied two addresses in author order. | Add Ishan Teredesai: `001@ddm.in`; Tushar Rahangadle: `002@ddm.in`. Recompile and inspect the IEEE conference PDF. These are author-supplied addresses; mailbox ownership or delivery was not tested. |

## Claims deliberately retained or rejected

- The pilot remains an interrupted 88/306-trial run. Its 23/48 sign-disagreement count is historical context, not the follow-up result.
- The follow-up remains 144/144 trials, with 10/36 disagreements and four sessions in one sitting.
- The 10.80- and 20.56-fold comparisons in the supplied advice describe earlier between-condition ratios. They are not substituted for the new within-trial ratios.
- The new experiment includes an idle P+C versus P power-integral increase as large as 10.65%. The old suggestion that monitoring changes integrated power by less than 1% cannot describe all new controls.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** Physical energy accuracy, a causal driver/firmware diagnosis, cross-device generality and statistical equivalence remain unestablished. The revision makes none of those claims.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** No public archive deposit or conference supplementary-file access has been completed by preparing these files. Do not report the artifact as publicly deposited or submitted until that action actually occurs.

## Submission recommendation

Submit the revised paper for consideration as Emerging Research after both authors review the final document and ensure reviewers can access the artifact. Another identical benchmark run is not needed for this revision. Further hardware, independent-day and external-meter experiments would support broader future claims; they are not evidence already present in this package.

The public deadline is 13 November 2026; the public call does not establish its exact cutoff time or timezone. The manuscript is prepared with the required IEEE conference class and within the eight-page limit. Source: https://greensworkshop.github.io/


## Update: author-selected GitHub route, 7 November 2026

The author reports that the actual HotCRP submission form offers no supplementary-material upload. The selected artifact location is https://github.com/titcsl/reuse-model, now included exactly in the paper. The publication package provides a repository README, the revised PDF, main LaTeX source, complete LaTeX project and full reproducibility ZIP. The raw data are kept inside the reproducibility ZIP so they can be distributed without uploading the large CSV individually through GitHub's browser interface. Publication and public downloadability still require an actual repository upload and a signed-out access check; inserting the address is not evidence that this has happened.
