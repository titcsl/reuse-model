import argparse
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
PAPER = 'GREENS_2027_Emerging_Research'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--analysis-only', action='store_true')
    args = parser.parse_args()
    for filename in ['analyze.py', 'render_results.py', 'verify_artifact.py']:
        subprocess.run([sys.executable, str(ROOT/filename)], cwd=ROOT, check=True)
    if args.analysis_only:
        return
    if shutil.which('pdflatex') is None:
        raise SystemExit('Analysis passed. Install a TeX distribution with pdflatex, or compile the LaTeX archive in Overleaf.')
    for run in range(2):
        result = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', PAPER+'.tex'], cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            print(result.stdout)
            raise SystemExit(result.returncode)
    log = (ROOT/(PAPER+'.log')).read_text()
    if 'Overfull' in log or 'undefined' in log or 'multiply defined' in log:
        raise SystemExit('The PDF compiled, but layout/reference warnings require review.')
    print(f'Built {ROOT/(PAPER+".pdf")}')


if __name__ == '__main__':
    main()
