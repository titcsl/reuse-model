# Reference and format audit: completed follow-up

The original seven references were checked against primary sources on 2 November 2026. Eight added works and the venue/publisher guidance were checked on 5 November 2026. The bibliography is unchanged in the completed-follow-up revision. The numbered entries below match the revised manuscript bibliography, in order of first citation. All 15 entries are cited in the text; none is inserted solely to increase the reference count. This targeted audit is not a systematic review or proof of novelty. No external figure or table is reproduced.

1. **Temporal-coherence survey (Scherzer et al., 2011).** Authors, title, venue, year, and pages 101-126 are verified in the TU Wien author record. The Eurographics publisher record supplies DOI `10.2312/EG2011/stars/101-126`.
   Primary sources: https://www.cg.tuwien.ac.at/research/publications/2011/scherzer2011c/ and https://diglib.eg.org/items/38d8f356-c74f-4cc5-b926-b6aa9665501b
   Used for the established temporal-reuse literature; no experimental result from this survey is attributed to the present implementation.

2. **Reverse reprojection caching (Nehab et al., 2007).** Author-hosted record verifies the five authors, title, venue/year, caching approach, and cache-refresh policies. HKUST's author-institution record verifies pages 25-35. A primary URL is used instead of an unverified DOI.
   Primary sources: https://gfx.cs.princeton.edu/gfx/pubs/Nehab_2007_ARS/index.php and https://researchportal.hkust.edu.hk/en/publications/accelerating-real-time-shading-with-reverse-reprojection-caching/
   Used to distinguish surface-point shading reuse from the benchmark's exact independent-tile state equality; not claimed as an implemented competitor.

3. **Rendering Elimination: Early Discard of Redundant Tiles in the Graphics Pipeline.** Anglada, de Lucas, Parcerisa, Aragon, Marcuello, and Gonzalez. HPCA 2019. The author-hosted published PDF verifies the authors, title, venue, year, and DOI `10.1109/HPCA.2019.00014`.
   Primary source: https://webs.um.es/jlaragon/papers/anglada_HPCA19a.pdf
   Used for the prior art in detecting redundant tiles from rendering inputs. No published speedup or energy percentage is transplanted into this experiment.

4. **Temporally Adaptive Shading Reuse for Real-Time Rendering and Virtual Reality.** Mueller, Neff, Voglreiter, Steinberger, and Schmalstieg. ACM Transactions on Graphics 40(2), article 11, 2021; DOI `10.1145/3446790`.
   Primary institutional record: https://tugraz.elsevierpure.com/en/publications/temporally-adaptive-shading-reuse-for-real-time-rendering-and-vir/
   Used for temporal shading reuse and perceptual constraints, not as an implemented benchmark competitor.

5. **K20 built-in sensor (Burtscher, Zecena, and Zong, 2014).** The author-hosted paper and publication list verify title, authors, venue/year, pages 28-36, and observed sampling/response anomalies.
   Primary sources: https://userweb.cs.txstate.edu/~burtscher/papers/gpgpu14.pdf and https://userweb.cs.txstate.edu/~burtscher/abstracts.html
   The bibliography uses the author-hosted paper URL. The K20 findings are historical context, not a calibration or correction for the RTX 4050.

6. **Accurate and Convenient Energy Measurements for GPUs: A Detailed Study of NVIDIA GPU's Built-In Power Sensor.** Yang, Adamek, and Armour. SC 2024.
   Official proceedings record: https://sc24.supercomputing.org/proceedings/tech_paper/tech_paper_pages/pap544.html
   The official record verifies title, authors, venue/year, and the general sensing result. The paper cites that accessible primary record instead of depending on a publisher DOI page that was not retrieved. It does not infer calibration of the RTX 4050.

7. **Dauner et al. (2026): measurement-frequency study.**
   Original PDF: https://hotcarbon.org/assets/2026/paper-46.pdf
   The footer identifies volume 6, issue 2 of ACM SIGENERGY Energy Informatics Review, July 2026. [REVIEWER NOTE: VERIFY FACT/SOURCE] A DOI and formal article page range were not supplied in the inspected copy; both are omitted. Its mechanism is not presumed to explain this experiment.

8. **GPUWattch (Leng et al., 2013).** The author-hosted ISCA paper verifies authors, published title, and the hardware-validated architectural modeling approach. The project-maintained citation block corroborates DOI `10.1145/2485922.2485964`.
   Primary sources: https://people.ece.ubc.ca/aamodt/publications/papers/gpuwattch.isca2013.pdf and https://github.com/accel-sim/accel-sim-framework/blob/dev/README.md
   The published paper uses the spelling Ahmed ElTantawy and plural "Optimizations"; those are preserved. No modeled energy result is imported into this experiment.

9. **Software power-meter comparison (Jay et al., 2023).** The author-hosted paper verifies scope, method, and all six author names. In particular, the PDF spells Vladimir Ostapenco and Benjamin Fichel; inaccurate spellings in an automatic search summary were not copied. IEEE's publication record confirms the conference/year and DOI `10.1109/CCGrid57682.2023.00020`.
   Primary sources: https://perso.ens-lyon.fr/laurent.lefevre/pdf/CCGRID2023_Ostapenco_Jay_Lefevre.pdf and https://ieeexplore.ieee.org/document/10171575/
   Used for meter scope, overhead, and comparison with external measurements. Its discussion of a 5% NVML qualification is not adopted as a current RTX 4050 accuracy bound; the manuscript uses NVIDIA's architecture-specific documentation for that issue.

10. **PowerSensor3.** Van der Vlugt et al. ISPASS 2025, pages 213-226; DOI `10.1109/ISPASS64960.2025.00028`.
   Primary institutional record: https://research.vu.nl/en/publications/powersensor3-a-fast-and-accurate-open-source-power-measurement-to/
   Author preprint: https://arxiv.org/abs/2504.17883
   Used only as an example of external instrumentation. The manuscript expressly states it was not used in this study.

11. **NVIDIA NVML API Reference: Device Queries.**
   https://docs.nvidia.com/deploy/nvml-api/latest/api/group__nvmlDeviceQueries.html
   Verified cumulative-energy units, power units, architecture-dependent power averaging, and the limited Fermi/Kepler scope of the stated +/-5% qualification. No RTX 4050 accuracy bound is asserted.

12. **Software-energy measurement guidelines (Ardito et al., 2019).** Publisher and author-institution records verify the four authors, title, journal/year, and DOI `10.1155/2019/5284645`; the article identifier is 5284645. The bibliography avoids a page-range inconsistency between metadata and downloadable-copy pagination.
   Primary sources: https://doi.org/10.1155/2019/5284645 and https://iris.polito.it/handle/11583/2769312
   Used for documented measurement procedures, reproducibility deliverables, and threats to validity. The manuscript does not claim a formal compliance assessment against that process.

13. **Measurement bias (Mytkowicz et al., 2009).** The author-group record supplies authors, title, ASPLOS venue/year, pages 265-276, and DOI `10.1145/1508244.1508275`. IBM Research corroborates the experimental-setup bias finding.
   Primary sources: https://sape.inf.usi.ch/publications/asplos09.html and https://research.ibm.com/publications/producing-wrong-data-without-doing-anything-obviously-wrong
   Used for a general methodological concern, not to diagnose the mechanism of the observed GPU counter disagreement. The two abstracts differ in survey counts; those counts are not used.

14. **Benchmark repetition (Kalibera and Jones, 2013).** The University of Kent author deposit verifies the title, authors, ISMM venue/year, DOI `10.1145/2464157.2464160`, and treatment of variation between builds, executions, and iterations.
   Primary source: https://kar.kent.ac.uk/33611/
   The deposit notes a correction to the conference version. Used for the distinction between experimental levels; no confidence interval from that method is computed or claimed for either the interrupted pilot or the completed follow-up.

15. **NVIDIA CUDA Driver API: Event Management.**
   https://docs.nvidia.com/cuda/cuda-driver-api/group__CUDA__EVENT.html
   Used for elapsed-event semantics. Event intervals are not equated to isolated shader execution or to energy.

Venue and disclosure sources checked on 5 November 2026:

- https://greensworkshop.github.io/
- https://conferences.ieeeauthorcenter.ieee.org/author-ethics/guidelines-and-policies/submission-policies/

IEEEtran distribution used unchanged: https://mirrors.ctan.org/macros/latex/contrib/IEEEtran.zip

The completed-follow-up manuscript now contains a scope-specific ChatGPT acknowledgment covering the abstract, Sections I–VIII, benchmark/analysis code and figures. The author-supplied emails `001@ddm.in` and `002@ddm.in` have now been added in author order; mailbox ownership or delivery was not tested. The author has designated https://github.com/titcsl/reuse-model for artifact access. Its public contents must be checked after upload; no DOI is claimed.

On 6 November 2026, the GREENS call, IEEE AI-content disclosure policy and NVML device-query documentation were revisited. The earlier audit also rechecked Nehab's author/institution records, PowerSensor3's institutional pagination, and the Dauner PDF. This record does not claim that all 15 papers were reread in full on 6 November.

The reviewer suggested additional Arafa and van Kempen citations. They were not inserted because the proposed additions had not received a full primary-source and relevance audit. A longer bibliography alone is not a stronger novelty argument.
