# Response to the earlier manuscript audit

This response summarizes the earlier audit's concerns rather than inventing verbatim reviewer quotations. The paper now treats the completed follow-up as its primary evidence and retains the interrupted pilot separately. Section references below refer to the revised eight-page manuscript.

## 1. Overall evaluation and change in contribution

The revised contribution is a bounded case study of acquisition-sensitive GPU telemetry in an exact-reuse benchmark. It is not a claim to have invented temporal reuse or established physically calibrated energy savings. The completed 144-trial run adds the missing controls and improves experimental completeness. It cannot resolve physical ground truth or generalize beyond the tested laptop by itself.

The new sparse-validation comparison reduces median frame wall time from 4.796 to 1.845 ms. Median apparent savings are 10.54% from the cumulative counter and 9.73% from integrated power. The counter and integral disagree in sign for 10 of 36 main-policy contrasts, compared with 23 of 48 in the pilot. These are separate runs with different protocols; the improvement is not treated as a pooled effect estimate.

## 2. Systematic response to methodological and presentation concerns

| Audit concern | Revision and evidence | Status |
|---|---|---|
| The pilot stopped before its planned design completed. | Section IV-A retains 88/306 and the manual interruption. The follow-up completes 144/144 trials in four fresh processes, with all planned conditions present. | Addressed prospectively; the pilot remains incomplete. |
| Repetition and order were weak. | There are four complete session/seed blocks per main scenario. Policy order balances position and immediate predecessors using a four-period Williams design. The stored plan is checked against every trial. | Improved; still one sitting and one device. |
| Frames and shared-baseline contrasts are not independent replications. | Sections IV-C and VII use the session/seed block as the comparison unit. Four paired values are summarized per cell, with observed ranges. The 36 contrasts share 12 full-render baselines. | Addressed. |
| No genuine no-launch control was measured. | Section III-C defines a context-resident host loop with no CUDA calls during warmup or measurement. Twelve such trials cover P, P+C and boundary-only modes. | Addressed. |
| The copy baseline was not pure idle. | The paper states exactly which uploads, events and copies it retains. Twelve copy controls complement the no-launch trials. | Addressed. |
| Continuous-counter monitoring had too few repetitions. | The follow-up includes 52 polling-sweep trials: six nominal intervals under P and P+C, plus boundary-only, in each of four sessions. | Addressed. |
| Query timing and actual polling rate were unclear. | Start-to-start jitter, actual timestamps and achieved intervals are retained. The 25-ms P+C condition achieves a median 30.7-ms interval across trial medians. | Addressed. |
| The large counter change needed a clearer denominator. | The paper centers the within-trial counter/integral ratio. Sweep medians range from 75.98 at nominal 25 ms to 3.22 at 1,000 ms. Idle P+C ratios are 152.90–198.22. | Addressed. |
| The polling anomaly could be related to rendering work. | The discrepancy survives no-launch and copy controls. Extra reported counter energy is associated with continuous-read count, with descriptive slopes of 5.49–5.98 reported J/read. No physical per-call cost is inferred. | Better discriminating evidence; mechanism unresolved. |
| All measurements appeared to remain in P8. | Section V-D reports 9,588 in-window main-trial state samples at P8/210 MHz. The sustained diagnostic has 601 samples at P0/2,685–2,700 MHz and ratios 1.0097–1.0220. | Addressed with sampled-state language. |
| A sustained-load comparison was missing. | Four uncapped 1920×1080 trials were added. The paper states that cadence, resolution and operating state all change, so this does not isolate a P-state effect. | Addressed as a diagnostic, not a causal test. |
| Explicit average/instantaneous power paths were untested. | Fields 185 and 186 succeed in 1,062 snapshots. The averaged path differs by approximately −4.89% and −4.74% in two sessions; the instantaneous path stays within −0.18% to +0.27% of the ordinary-power integral. | Addressed; no field is declared ground truth. |
| Monitoring overhead could be understated. | The paper retains the largest idle P+C versus P integral increase, 10.65%, rather than calling all differences negligible. | Addressed. |
| Timing spread and stronger baselines were missing. | Table II reports trial-median quartiles, GPU/render/copy intervals and absolute power. Both known-dirty and compact baselines remain. Additional timing components are in `results/timing_components.csv`. | Addressed. |
| CUDA events were being overinterpreted. | Section IV-B explains that elapsed stream intervals may include host submission gaps. A nonzero render interval is not proof of a shader launch. | Addressed. |
| Zero mismatches could be overstated as a proof. | Section V-A reports 1,788 tested comparisons, 1,021,372,974 compared pixels and 144 final-image checks, all passing. The detecting negative control has 1,156,300 mismatched pixels. The conditional dependency argument is separated from empirical coverage. | Addressed within the restricted model. |
| All-changed cases and small effects complicated sign counts. | The main result retains all 36 contrasts. Six of the ten disagreements are all-changed; excluding that regime leaves 4/24. Seven disagreements have both absolute effects above 1%; three exceed 5%. | Addressed as sensitivity descriptions. |
| A/A variability did not establish equivalence. | Four adjacent A/A pairs have sample SDs of 2.60 and 0.76 percentage points for counter and integral savings. No equivalence margin, confidence interval or universal noise floor is inferred. | Addressed by limiting the claim. |
| The pilot might have sampled only one frame phase. | Section V-E reports the timestamp check: 85 of 86 monitored completed pilot trials occupy all 16 nominal-phase bins; one occupies 15. This weakens that particular hypothesis without recovering internal sensor timing. | Addressed with the available data. |
| Long pauses and platform details were unexplained. | The two pilot gaps remain explicitly unexplained. The follow-up records registry build 26300.9818, DisplayVersion 26H2, driver 581.86 and NVML 13.581.86, with no unsupported release-channel inference. | Partly resolved; historical gap causes remain unknown. |
| Background interference and continuous-state claims were concerns. | The paper acknowledges recorded background applications, sampled states, AC endpoints and the limits of the watchdog. Static full-render power still ranges from 2.57 to 3.24 W across sessions. | Addressed as a limitation. |
| Reproducibility and AI disclosure were incomplete. | The archive includes raw data, exact-source recovery, protocols, derived tables, source checksums and a one-command analysis build. The acknowledgment identifies ChatGPT and its actual scope. | Author-supplied contacts are now included; actual artifact upload or public deposit remains a submission action. |

## 3. Factual and reference audit

The supplied CSVs are unchanged. Their hashes, embedded source hashes and protocol hashes pass. Independent integration from the raw power readings and query timestamps agrees with the recorded follow-up integrals within 5.7×10^-13 J. All 140 paced follow-up warmup/measurement trace pairs can be regenerated from the recorded seeds. The 144 trial plans match the executed design. One idle host-loop deadline miss is retained; no main-policy trial has a deadline miss.

The manuscript retains 15 relevant references. The bibliography is supported by the existing primary-source audit and the later audit corrections in `REFERENCE_AUDIT.md`. No additional studies were invented to increase the count. Nehab's 25–35 and PowerSensor3's 213–226 page ranges are retained; a reviewer's inability to verify a field was not treated as proof that it was wrong. The Dauner citation uses the inspected publication footer and URL without an invented DOI or page range.

Unresolved claims remain explicitly bounded:

- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** No external meter establishes either estimator's physical accuracy on this laptop. Physical savings and equivalence are not claimed.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** The cause of the counter anomaly is unknown. The data establish an association with acquisition and workload regime, not a specific driver or firmware defect.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** The historical causes of the pilot's two long pauses are not recorded. They must not be replaced with an invented account of sleep, console selection or thermal behavior.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** Four sessions do not establish generality across days, GPUs, drivers or applications.
- **[REVIEWER NOTE: VERIFY FACT/SOURCE]** The author has designated https://github.com/titcsl/reuse-model and the paper includes that URL. Public access to the uploaded files must be confirmed before submission. No DOI is claimed. The author-supplied email addresses have been included.

## 4. Recommendation and remaining actions

The completed follow-up addresses the principal missing-control requests. Another identical run is not needed to regenerate the paper or to replace unfavorable observations. The package supports submission for consideration as an exploratory Emerging Research case study, after the author actions below. This assessment is not an acceptance decision or certification of physical energy accuracy.

1. Confirm the supplied author-contact mapping on page one: Ishan `001@ddm.in`; Tushar `002@ddm.in`. The revised PDF has been recompiled.
2. Have both authors inspect and approve the final claims, reference entries, affiliation, authorship and AI disclosure.
3. Publish the current artifact at the GitHub URL in the paper, verify signed-out access, and submit the eight-page PDF under Emerging Research. The author reports that the form has no supplementary-upload option.
4. Keep the submitted paper and repository artifact versions consistent. Creating the ZIP or inserting its URL does not itself publish the files.
5. For a future paper asserting physical energy savings, add an independent measurement design and replication across operating conditions. Those additional experiments are outside the claims of this revision.


The additional advice supplied after the completed-follow-up revision is assessed separately in `REVISION_DECISIONS.md`. Its request for fresh monitoring repetitions is already satisfied by the follow-up; its proposed 23/48 contribution wording is not substituted for the current 10/36 result.
