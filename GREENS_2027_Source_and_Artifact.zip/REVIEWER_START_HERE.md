# Reviewer starting point

This package accompanies *Auditing Energy Claims for Exact Frame Reuse on a Laptop GPU*. It contains the interrupted pilot and completed follow-up as separate acquisitions. The manuscript's primary results use the follow-up. Project address: https://github.com/titcsl/reuse-model.

## Inspect the evidence without running an experiment

| Question | File |
|---|---|
| Did the follow-up complete? | `results/followup_audit.json`: 144 completed trials, four process sessions in `results/followup_protocol.json` |
| What are the individual policy comparisons? | `results/followup_pairs.csv`: 36 contrasts in 12 main blocks |
| What changed with polling? | `results/followup_sweep_pairs.csv`, `results/followup_sweep_fits.csv` and `results/followup_queries.csv` |
| What do idle/copy and sustained controls show? | `results/followup_control_pairs.csv` and the `sustained_load` rows in `results/followup_trials.csv` |
| Are the original readings available? | Both unchanged CSVs in `data/` |
| Which program produced the readings? | Embedded source in each CSV; use `restore_executed.py` to recover and verify it |
| What was checked in the readable derivative? | `provenance/readable_source.json` and `results/package_validation.json` |

## Rebuild results from the existing CSVs

Use Python 3.12 with the pinned dependencies, from the extracted package directory:

```sh
python -m pip install -r requirements.txt
python build.py --analysis-only
```

This checks input hashes, reconstructs energy totals and power integrals, produces the tables and figures, checks source provenance, and regenerates the paced traces from their seeds. It does not require or launch a GPU workload. The expected follow-up summary is 144 trials, 204,297 measured iterations, 1,788 correctness comparisons, 144 passing final-image checks, and 10 opposite-sign contrasts out of 36. All 140 paced warmup/measurement trace pairs are reproducible. See `README.md` for virtual-environment and LaTeX instructions.

## Recollect hardware data

Follow the separate acquisition instructions in `README.md`. Restore the exact source before an exact-source replication; the readable benchmark has a different checksum because of documented formatting and comment removal. A new acquisition is a separate dataset, and incomplete results should be retained. The analysis is intentionally fixed to the supplied raw-file hashes.

## Interpretation

Individual frames are not independent energy replications. Three policy contrasts share each full-render baseline. The four follow-up process sessions occurred in one sitting on one laptop. Both energy estimates come from exposed NVML telemetry, with no independent meter. The artifact makes the observed disagreement auditable; it does not establish physical calibration.
