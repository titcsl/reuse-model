# GREENS 2027 submission guide

Venue and IEEE policy checked on 6 November 2026. On 7 November, the author reported that the HotCRP form has no supplementary-material upload and selected https://github.com/titcsl/reuse-model for the artifact. This package prepares the material; it does not submit it or guarantee acceptance.

## Author details and final review

The first page now includes the supplied author names, institution and contact addresses: Ishan Teredesai, `001@ddm.in`; Tushar Rahangadle, `002@ddm.in`. This follows the author order supplied in the conversation. GREENS uses single-anonymous review and requests these details on page one. Mailbox ownership or delivery was not independently tested.

Both authors should read the final paper, check their affiliation and author order, and confirm that they can take responsibility for the claims and code. This document does not attest that this author review has already occurred. If there is relevant funding, a conflict, prior publication or another active submission, disclose it accurately when asked; no declaration has been fabricated.

## What to submit

| Item | Initial submission use |
|---|---|
| Manuscript PDF | Upload the rebuilt eight-page paper as **Emerging Research** at the official HotCRP site. |
| Title, abstract, authors and contacts | Enter these accurately in the submission form. |
| Full artifact ZIP | Publish `GREENS_2027_Source_and_Artifact.zip` in the public `titcsl/reuse-model` GitHub repository. The paper links to that repository. The author reports that HotCRP has no supplementary upload. |
| LaTeX ZIP | Keep for source requests and camera-ready preparation; it is not a replacement for the review PDF. |
| Reviewer-response Markdown | Keep with the revision record; upload only if the venue requests a response. This is not a claim that GREENS previously reviewed this work. |

Official submission site: https://icse2027-greens.hotcrp.com

The public call lists **13 November 2026** as the submission date. The exact closing time and timezone were not established from the public call; check the submission system. Emerging Research allows up to eight pages. The supplied PDF is eight pages including references and uses `\documentclass[10pt,conference]{IEEEtran}` without margin, font-size or spacing overrides. Pagination and reference/layout warnings have been rechecked after adding the contacts. This completed study is not a stage-one Registered Report.

## AI disclosure and artifact availability

The acknowledgment identifies OpenAI ChatGPT and its assistance with the abstract, Sections I–VIII, benchmark/analysis code and figures. This is more specific than a grammar-only acknowledgment and reflects the assistance actually provided. IEEE's policy asks for the system, affected sections and scope. The paper does not state that the authors have already independently verified every AI-assisted output.

The manuscript now points to https://github.com/titcsl/reuse-model. Before submitting, make the repository public and upload the current paper, LaTeX project and full artifact archive there. Open that address in a signed-out or private browser window, download the full artifact ZIP and confirm that it opens. Preparing this package or inserting the URL does not itself publish the files. No public availability is assumed solely from the author-supplied URL, and no DOI is invented.

Use the files in `REUSE_MODEL_GitHub_Package.zip` for a browser upload: extract that outer package once and upload the six files listed in its `UPLOAD_TO_GITHUB.md`. Keep the inner source-and-artifact ZIP intact; it holds the two original CSVs, including the large follow-up CSV. The raw measurements remain unchanged. The public README points readers to the complete downloadable artifact and separates analysis from new acquisition.

For an initial paper submission, an acceptance letter, copyright transfer, registration receipt and presentation slides are not supplied here. Follow the organizer's later instructions if the paper is accepted.

## Final check

1. Verify the supplied contacts, title, affiliation, author order and disclosure, and have both authors review the paper.
2. Recompile and inspect every page; keep all content within eight pages.
3. Upload the PDF and enter matching metadata under Emerging Research.
4. Confirm that the paper's GitHub link works without signing in and that the current artifact ZIP downloads; then verify the PDF submitted in HotCRP.
5. Retain the exact submitted PDF, source archive and receipt.

Sources:

- https://greensworkshop.github.io/
- https://conferences.ieeeauthorcenter.ieee.org/author-ethics/guidelines-and-policies/submission-policies/
